// See SetupX_Template.h for all options available
#define USER_SETUP_ID 304
 
#define SUPPORT_TRANSPARENCY
//#define ESP32_D1 //-- funktioniert nicht !!!! SPI & LittleFs ???

#define ESP32_S2
//#define ESP32_S3

#define GC9A01_DRIVER
//#define GC9D01_DRIVER
//#define ILI9341_DRIVER



#ifdef GC9A01_DRIVER
#define TFT_WIDTH 240
#define TFT_HEIGHT 240
#endif


#ifdef GC9D01_DRIVER
#define TFT_WIDTH 160
#define TFT_HEIGHT 160
#endif

#ifdef ILI9341_DRIVER
#define TFT_WIDTH 240
#define TFT_HEIGHT 240
#endif


#define TFT_MISO -1

#ifdef ESP32_S3
/* #define TFT_MOSI   15 // In some display driver board, it might be written as "SDA" and so on.
#define TFT_SCLK  14
#define TFT_CS   5  // Chip select control pin
#define TFT_DC   27  // Data Command control pin
#define TFT_RST  33  // Reset pin (could connect to Arduino RESET pin)
#define TFT_BL   32  // LED back-light
*/

/*#define TFT_MOSI 11
#define TFT_SCLK 10
#define TFT_CS   9
#define TFT_DC   8
#define TFT_RST  12
#define TFT_BL   40
#define TFT_BACKLIGHT_ON HIGH */

#define TFT_MISO 12
#define TFT_MOSI 11
#define TFT_SCLK 10
#define TFT_CS 9 // Chip select control pin
#define TFT_DC 8 // Data Command control pin
#define TFT_RST 14
#define TFT_BL 2
#define TFT_BACKLIGHT_ON HIGH

#define USE_HSPI_PORT
#endif


#ifdef ESP32_D1
#define TFT_DC    5  // Data Command control pin
#define TFT_CS    26  // Chip select control pin
#define TFT_SCLK  18
#define TFT_MOSI  23
#define TFT_RST   19  // Reset pin (could connect to RST pin)

#define TFT_BL    21
#define USE_HSPI_PORT
#endif

#ifdef ESP32_S2
#define TFT_DC    33 // Data Command control pin
#define TFT_CS    12 // Chip select control pin 
#define TFT_SCLK  7 
#define TFT_MOSI  11 
#define TFT_RST   5  // Reset pin (could connect to RST pin)

#ifdef GC9D01
#define TFT_BL    3
#endif

#define USE_HSPI_PORT

#endif

#define TOUCH_CS -1

#define TFT_BACKLIGHT_ON HIGH

#define LOAD_GLCD   // Font 1. Original Adafruit 8 pixel font needs ~1820 bytes in FLASH
// #define LOAD_FONT2  // Font 2. Small 16 pixel high font, needs ~3534 bytes in FLASH, 96 characters
// #define LOAD_FONT4  // Font 4. Medium 26 pixel high font, needs ~5848 bytes in FLASH, 96 characters
// #define LOAD_FONT6  // Font 6. Large 48 pixel font, needs ~2666 bytes in FLASH, only characters 1234567890:-.apm
// #define LOAD_FONT7  // Font 7. 7 segment 48 pixel font, needs ~2438 bytes in FLASH, only characters 1234567890:.
// #define LOAD_FONT8  // Font 8. Large 75 pixel font needs ~3256 bytes in FLASH, only characters 1234567890:-.
// #define LOAD_GFXFF  // FreeFonts. Include access to the 48 Adafruit_GFX free fonts FF1 to FF48 and custom fonts
// #define SMOOTH_FONT



                       
//#define SPI_FREQUENCY  10000000
#define   SPI_FREQUENCY  60000000



//#define SPI_READ_FREQUENCY  20000000

//#define SPI_FREQUENCY  27000000
//#define SPI_READ_FREQUENCY  20000000

